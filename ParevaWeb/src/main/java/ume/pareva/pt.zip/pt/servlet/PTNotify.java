package ume.pareva.pt.servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import ume.pareva.cms.MobileClub;
import ume.pareva.cms.MobileClubBillingTry;
import ume.pareva.cms.MobileClubCampaign;
import ume.pareva.cms.UmeTempCmsCache;
import ume.pareva.dao.CpaLoggerDao;
import ume.pareva.dao.MobileBillingDao;
import ume.pareva.dao.UmeMobileClubUserDao;
import ume.pareva.pojo.SdcMobileClubUser;
import ume.pareva.pojo.UmeDomain;
import ume.pareva.pt.util.UmeRequest;
import ume.pareva.userservice.RegionalDate;
import ume.pareva.userservice.StopUser;


public class PTNotify extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger( PTNotify.class.getName());
	
	@Autowired
	UmeRequest umeRequest;
	
	@Autowired
    StopUser stopuser;
	
	@Autowired
    UmeMobileClubUserDao umemobileclubuserdao;
    
	@Autowired
    CpaLoggerDao cpaloggerdao;
	
	 @Autowired
	 RegionalDate regionaldate;
	 
	 @Autowired
	 MobileBillingDao mobilebillingdao;
       
    public PTNotify() {
        super();
    }
    
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,
                config.getServletContext());
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UmeDomain dmn=umeRequest.getDomain();
		MobileClub club = UmeTempCmsCache.mobileClubMap.get(dmn.getUnique());
        String type=umeRequest.get("type");
		//String service=umeRequest.get("service");
		String retry=umeRequest.get("retry");
		MobileClubCampaign cmpg = null;
		if(type.equals("CHARGE_OK")){
			//String movementDate=umeRequest.get("movementDate");
			//float value=Float.parseFloat(umeRequest.get("value"));
			//String currrency=umeRequest.get("currency");
			//String mcc=umeRequest.get("mcc");
			//String mnc=umeRequest.get("mnc");
			String transactionId=umeRequest.get("transactionId");
			String subscriptionId=umeRequest.get("subscriptionId");
			//String msisdn=umeRequest.get("msisdn");
			//String subscriberId=umeRequest.get("subscriberId");
			if(!retry.equals("")){
				logger.error("Exception: Connection or Read Timeout, Notification Type - {}, SubscriptionId - {}, Retry Times - {}",type,subscriptionId,retry);
			}else{
				SdcMobileClubUser clubUser = umemobileclubuserdao.getClubUserByMsisdn(subscriptionId, club.getUnique());
				String campaignId=clubUser.getCampaign();
				if (campaignId != null && !campaignId.equals("")) {
					cmpg = UmeTempCmsCache.campaignMap.get(campaignId);
				}
				if (cmpg != null && cmpg.getSrc().toLowerCase().endsWith("cpa") && cmpg.getCpaType().equalsIgnoreCase("billing")) {
					// 2016.01.13 - AS - Removed commented code, check repo history if needed
					int insertedRows = cpaloggerdao.insertIntoCpaLogging(clubUser.getParsedMobile(), cmpg.getUnique(), club.getUnique(), 10, clubUser.getNetworkCode(), cmpg.getSrc());
				}
				String responseCode="";
				Date subscribedDate=clubUser.getSubscribed();
				Date today=regionaldate.getRegionalDate(club.getRegion(), new Date());
				if(DateUtils.isSameDay(subscribedDate,today)){
					responseCode="003";
				}else{
					responseCode="00";
				}
				updateBillingDate(clubUser);
				insertBillingTryForUser(clubUser,club,transactionId,responseCode);
			}
			
		}else if(type.equals("UNSUBSCRIBE")){
			String subscriptionId=umeRequest.get("subscriptionId");
			if(!retry.equals("")){
				logger.error("Exception: Connection or Read Timeout, Notification Type - {}, SubscriptionId - {}, Retry Times - {}",type,subscriptionId,retry);
			}else{
				stopuser.stopSingleSubscriptionNormal(subscriptionId, club.getUnique(), request, response);
			}
		}
	}
	
	public void insertBillingTryForUser(SdcMobileClubUser clubUser,MobileClub club,String transactionId,String responseCode){
		MobileClubBillingTry mobileClubBillingTry = new MobileClubBillingTry();
		mobileClubBillingTry.setTransactionId(transactionId);
		mobileClubBillingTry.setResponseCode(responseCode);
		mobileClubBillingTry.setCreated(new Date());
		mobileClubBillingTry.setRegionCode(club.getRegion());
		mobileClubBillingTry.setClubUnique(club.getUnique());
		mobileClubBillingTry.setCampaign(clubUser.getCampaign());
		mobilebillingdao.insertBillingTry(mobileClubBillingTry);
	}
    
    public void updateBillingDate(SdcMobileClubUser clubUser){
		Date billingRenew =new Date();
	    Date billingEnd=DateUtils.addDays(billingRenew, 7);
	    clubUser.setBillingRenew(billingRenew);
	    clubUser.setBillingEnd(billingEnd);
	    umemobileclubuserdao.saveItem(clubUser);
	}
	
}
