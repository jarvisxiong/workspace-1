package ume.pareva.fr;

public class FRConstant {
	
	public static final String LOGIN="universalmobile";
	public static final String PASSWORD="56gnP15A";
	public static final String SERVICE_ID="23461";
	
	public static final String NETWORK_INFO_URL="http://billing.virgopass.com/api_v1.5.php?getNetworkInfo";   
	public static final String USER_INFO_URL="http://billing.virgopass.com/api_v1.5.php?getUserInfo";
	public static final String TOKEN_URL="http://billing.virgopass.com/api_v1.5.php?getToken";   
	public static final String SUBSCRIPTION_CANCEL_URL="http://billing.virgopass.com/api_v1.5.php?resiliation";   
	public static final String SUBSCRIPTION_URL="http://billing.virgopass.com/api_v1.5.php?subscription";
	
	public static final String FROM="no-reply@fr.x-stream.mobi";
	   
}
